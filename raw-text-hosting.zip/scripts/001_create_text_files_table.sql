-- Create table for storing raw text files
CREATE TABLE IF NOT EXISTS public.text_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content TEXT NOT NULL,
  filename TEXT,
  content_type TEXT DEFAULT 'text/plain',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS for security
ALTER TABLE public.text_files ENABLE ROW LEVEL SECURITY;

-- Allow public read access (since this is a public text hosting service)
CREATE POLICY "Allow public read access" ON public.text_files 
  FOR SELECT USING (true);

-- Allow public insert access (anyone can upload text)
CREATE POLICY "Allow public insert access" ON public.text_files 
  FOR INSERT WITH CHECK (true);

-- Allow public update access by ID (for overwriting files)
CREATE POLICY "Allow public update access" ON public.text_files 
  FOR UPDATE USING (true);

-- Allow public delete access by ID
CREATE POLICY "Allow public delete access" ON public.text_files 
  FOR DELETE USING (true);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_text_files_id ON public.text_files(id);
CREATE INDEX IF NOT EXISTS idx_text_files_created_at ON public.text_files(created_at);
