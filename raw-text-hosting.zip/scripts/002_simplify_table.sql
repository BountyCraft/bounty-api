-- Modify table to support the simplified single-content approach
ALTER TABLE text_files DROP CONSTRAINT IF EXISTS text_files_pkey;
ALTER TABLE text_files ADD PRIMARY KEY (id);

-- Insert or update the 'latest' record structure
INSERT INTO text_files (id, content, content_type, filename, created_at, updated_at)
VALUES ('latest', 'No content yet', 'text/plain', null, NOW(), NOW())
ON CONFLICT (id) DO NOTHING;
