import { supabase } from "@/lib/supabase"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const { data, error } = await supabase.from("text_files").select("updated_at").eq("id", "latest").single()

    const status = {
      status: "ok",
      last_updated: data?.updated_at || null,
    }

    return NextResponse.json(status, {
      status: 200,
      headers: { "Content-Type": "application/json" },
    })
  } catch (error) {
    console.error("Status check error:", error)
    return NextResponse.json({ status: "error", last_updated: null }, { status: 500 })
  }
}
