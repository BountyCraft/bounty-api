import { supabase } from "@/lib/supabase"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (authHeader !== "x7pQzI") {
      return new NextResponse("Unauthorized", { status: 401 })
    }

    const content = await request.text()

    if (!content) {
      return new NextResponse("No content provided", { status: 400 })
    }

    await supabase.from("text_files").delete().neq("id", "nonexistent")

    const { error } = await supabase.from("text_files").insert({
      id: "latest",
      content: content,
      content_type: request.headers.get("content-type") || "text/plain",
      filename: request.headers.get("x-filename") || null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })

    if (error) {
      console.error("Database error:", error)
      return new NextResponse("Failed to store content", { status: 500 })
    }

    return new NextResponse("Content stored successfully", {
      status: 200,
      headers: { "Content-Type": "text/plain" },
    })
  } catch (error) {
    console.error("Server error:", error)
    return new NextResponse("Internal server error", { status: 500 })
  }
}

export async function GET() {
  try {
    const { data, error } = await supabase
      .from("text_files")
      .select("content, content_type")
      .eq("id", "latest")
      .single()

    if (error || !data) {
      return new NextResponse("No content found", {
        status: 404,
        headers: { "Content-Type": "text/plain" },
      })
    }

    return new NextResponse(data.content, {
      status: 200,
      headers: {
        "Content-Type": data.content_type || "text/plain",
      },
    })
  } catch (error) {
    console.error("Server error:", error)
    return new NextResponse("Internal server error", { status: 500 })
  }
}
