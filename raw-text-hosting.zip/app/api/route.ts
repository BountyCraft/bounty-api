import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const content = await request.text()

    if (!content) {
      return new NextResponse("No content provided", { status: 400 })
    }

    const cookieStore = await cookies()
    const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
          } catch {
            // The `setAll` method was called from a Server Component.
            // This can be ignored if you have middleware refreshing
            // user sessions.
          }
        },
      },
    })

    // Store as the latest content (always use id 'latest')
    const { error } = await supabase.from("text_files").upsert({
      id: "latest",
      content: content,
      content_type: request.headers.get("content-type") || "text/plain",
      filename: request.headers.get("x-filename") || null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })

    if (error) {
      console.error("Database error:", error)
      return new NextResponse("Failed to store content", { status: 500 })
    }

    return new NextResponse("Content stored successfully", {
      status: 200,
      headers: { "Content-Type": "text/plain" },
    })
  } catch (error) {
    console.error("Server error:", error)
    return new NextResponse("Internal server error", { status: 500 })
  }
}

export async function GET() {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
          } catch {
            // The `setAll` method was called from a Server Component.
            // This can be ignored if you have middleware refreshing
            // user sessions.
          }
        },
      },
    })

    // Get the latest content
    const { data, error } = await supabase
      .from("text_files")
      .select("content, content_type")
      .eq("id", "latest")
      .single()

    if (error || !data) {
      return new NextResponse("No content found", {
        status: 404,
        headers: { "Content-Type": "text/plain" },
      })
    }

    return new NextResponse(data.content, {
      status: 200,
      headers: {
        "Content-Type": data.content_type || "text/plain",
      },
    })
  } catch (error) {
    console.error("Server error:", error)
    return new NextResponse("Internal server error", { status: 500 })
  }
}
