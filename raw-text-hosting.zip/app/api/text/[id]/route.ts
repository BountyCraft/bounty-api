import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

// GET - Retrieve text file by ID (returns raw content)
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const supabase = await createClient()

    // Fetch the text file
    const { data, error } = await supabase
      .from("text_files")
      .select("content, content_type, filename")
      .eq("id", id)
      .single()

    if (error || !data) {
      return NextResponse.json({ error: "Text file not found" }, { status: 404 })
    }

    // Return raw content with appropriate headers
    const headers = new Headers()
    headers.set("Content-Type", data.content_type || "text/plain")

    // Add filename to Content-Disposition if available
    if (data.filename) {
      headers.set("Content-Disposition", `inline; filename="${data.filename}"`)
    }

    // Prevent caching for dynamic content
    headers.set("Cache-Control", "no-cache, no-store, must-revalidate")

    return new NextResponse(data.content, {
      status: 200,
      headers,
    })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// PUT - Update/overwrite existing text file
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const supabase = await createClient()

    // Get new content from request body
    const body = await request.text()

    if (!body) {
      return NextResponse.json({ error: "Content is required" }, { status: 400 })
    }

    // Get optional filename and content-type from headers
    const filename = request.headers.get("x-filename") || null
    const contentType = request.headers.get("content-type") || "text/plain"

    // Update the existing file
    const { data, error } = await supabase
      .from("text_files")
      .update({
        content: body,
        filename,
        content_type: contentType,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select("id")
      .single()

    if (error || !data) {
      return NextResponse.json({ error: "Text file not found or update failed" }, { status: 404 })
    }

    return NextResponse.json({
      id: data.id,
      message: "Text file updated successfully",
    })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// DELETE - Delete text file
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const supabase = await createClient()

    // Delete the text file
    const { error } = await supabase.from("text_files").delete().eq("id", id)

    if (error) {
      return NextResponse.json({ error: "Text file not found or delete failed" }, { status: 404 })
    }

    return NextResponse.json({
      message: "Text file deleted successfully",
    })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
