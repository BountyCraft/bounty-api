import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

// POST - Upload new text file
export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Get content from request body
    const body = await request.text()

    if (!body) {
      return NextResponse.json({ error: "Content is required" }, { status: 400 })
    }

    // Get optional filename and content-type from headers
    const filename = request.headers.get("x-filename") || null
    const contentType = request.headers.get("content-type") || "text/plain"

    // Insert into database
    const { data, error } = await supabase
      .from("text_files")
      .insert({
        content: body,
        filename,
        content_type: contentType,
      })
      .select("id")
      .single()

    if (error) {
      console.error("Database error:", error)
      return NextResponse.json({ error: "Failed to store text file" }, { status: 500 })
    }

    // Return the ID and URL for accessing the file
    const baseUrl = request.nextUrl.origin
    const url = `${baseUrl}/api/text/${data.id}`

    return NextResponse.json({
      id: data.id,
      url,
      message: "Text file stored successfully",
    })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
