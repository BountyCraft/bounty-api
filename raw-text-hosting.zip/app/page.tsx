"use client"

export default function HomePage() {
  return (
    <div style={{ fontFamily: "monospace", padding: "20px" }}>
      <h1>Home Page</h1>

      <div style={{ marginTop: "20px" }}>
        <div style={{ marginBottom: "10px" }}>
          <button
            onClick={() => (window.location.href = "/brainrot")}
            style={{
              padding: "10px 20px",
              marginRight: "10px",
              cursor: "pointer",
            }}
          >
            Go to /brainrot
          </button>
        </div>

        <div>
          <button
            onClick={() => (window.location.href = "/status")}
            style={{
              padding: "10px 20px",
              cursor: "pointer",
            }}
          >
            Go to /status
          </button>
        </div>
      </div>
    </div>
  )
}
